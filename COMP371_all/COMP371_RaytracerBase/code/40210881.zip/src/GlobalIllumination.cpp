#include "SceneInfo.h"
#include "Geometry.h"
#include "Light.h"
#include "BufferUtils.h"
#include "TracerUtils.h"
#include "PairedRoot.h"
#include "Types.h"
#include "Ray.h"

#include "RenderTechniques.h"

#include <Eigen/Dense>

#include <iostream>
#include <algorithm>
#include <string>
#include <vector>
#include <cmath>


void renderSceneGlobal(Buffer& buffer, SceneInfo& scene, OutputInfo& output)
{
    // Look through all the grid holes
    const int IMAGE_HEIGHT = output.size[1];
    const int IMAGE_WIDTH  = output.size[0];

    // Pixel size
    const double DELTA = 2 * tan(output.fov / 2) / IMAGE_HEIGHT;

    // Directions on the viewport
    Vec3 up = output.up;
    Vec3 side = output.lookat.cross(output.up).normalized();
    Point viewport_center = output.center + output.lookat;

    // Coefficients to reach first pixel on viewport
    float delta_u =  (IMAGE_HEIGHT * DELTA - DELTA) / 2;
    float delta_s = -(IMAGE_WIDTH  * DELTA - DELTA) / 2;


    
    // Stratified sampling parameters
    // len 1    rays per pixel using uniform random
    // len 2    a x a grid with b rays inside
    // len 3    a x b grid with c rays inside

    // Stratify
    uint rays_per_grid_cell(0);
    uint number_of_columns(0);
    uint number_of_rows(0);

    const int GLOBAL_RAYS_SPECIFICATION = output.raysperpixel.size();

    if (GLOBAL_RAYS_SPECIFICATION == 1)
    {
        rays_per_grid_cell = output.raysperpixel[0];
        number_of_columns  = 1;
        number_of_rows     = 1;
    } else if (GLOBAL_RAYS_SPECIFICATION == 2)
    {
        rays_per_grid_cell = output.raysperpixel[1];
        number_of_columns  = output.raysperpixel[0];
        number_of_rows     = output.raysperpixel[0];    
    } else if (GLOBAL_RAYS_SPECIFICATION == 3)
    {
        rays_per_grid_cell = output.raysperpixel[2];
        number_of_columns  = output.raysperpixel[1];
        number_of_rows     = output.raysperpixel[0];    
    }

    std::cout << "rgc" << rays_per_grid_cell << std::endl;
    std::cout << "cols" << number_of_columns << std::endl;
    std::cout << "rows" << number_of_rows << std::endl;

    exit(1);

    // Traveling on xy axis of the viewport
    for (int y = 0; y < output.size[1]; y++)
    {
        Vec3 u_vec = up * (delta_u - y * DELTA);

        for (int x = 0; x < output.size[0]; x++)
        {
            Vec3 s_vec = side * (delta_s + x * DELTA); 
            Point grid_point = viewport_center + u_vec + s_vec;





        }

    }
}