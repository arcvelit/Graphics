#include "OutputInfo.h"

#include "json.hpp"

#include <Eigen/Dense>

#include <vector>

#define _USE_MATH_DEFINES

#include <cmath>


OutputInfo::OutputInfo(const nlohmann::json &output)
{
    lookat = Eigen::Vector3f(output["lookat"][0], output["lookat"][1], output["lookat"][2]);
    center = Eigen::Vector3f(output["centre"][0], output["centre"][1], output["centre"][2]);
    bkc = {output["bkc"][0], output["bkc"][1], output["bkc"][2]};
    up = Eigen::Vector3f(output["up"][0], output["up"][1], output["up"][2]);
    ai = {output["ai"][0], output["ai"][1], output["ai"][2]};

    filename = output["filename"];
    size[0] = output["size"][0];
    size[1] = output["size"][1];

    // Back to radians
    fov = output["fov"];
    fov *= (M_PI / 180.0f);

    // Normalise
    lookat.normalize();
    up.normalize();

    // Optional fields

    // Default values
    twosiderender = true;
    maxbounces = 0.0;
    probterminate = 0.0;

    //
    if (output.contains("probterminate")) { probterminate = output["probterminate"]; }
    if (output.contains("twosiderender")) { twosiderender = output["twosiderender"]; }
    if (output.contains("antialiasing")) { antialiasing = output["antialiasing"]; }
    if (output.contains("globalillum")) { globalillum = output["globalillum"]; }
    if (output.contains("maxbounces")) { maxbounces = output["maxbounces"]; }
    if (output.contains("raysperpixel"))
    {
        nlohmann::json rpp = output["raysperpixel"];
        int size = rpp.size();
        for (int i = 0; i < size; i++) raysperpixel.push_back(rpp[i]);
    } else if (antialiasing || globalillum) 
    {
        raysperpixel.push_back(10);
        raysperpixel.push_back(10);
    }
}